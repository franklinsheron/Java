package com.example;

import com.example.dao.EmployeeDao;
import org.hibernate.cfg.Configuration;
import come.example.model.EmployeeMan;

public class App {

	public static void main(String[] args) 
	{
		EmployeeDao empdao  = new EmployeeDao();
		EmployeeMan EmpM = new EmployeeMan();
		EmpM.setName("Franklin");
		EmpM.setSalary(30000);
		empdao.SaveUser(EmpM);
		EmployeeMan EmpM1 = new EmployeeMan();
		EmpM1.setName("Alex");
		EmpM1.setSalary(40000);
		empdao.SaveUser(EmpM1);
		EmployeeMan EmpM2 = new EmployeeMan();
		EmpM2.setName("Anderson");
		EmpM2.setSalary(34000);
		empdao.SaveUser(EmpM2);
		
		empdao.deleteUser(3);
		
	}

}
