package com.example.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import come.example.model.EmployeeMan;

public class EmployeeDao implements IEmployeeDao
{
private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public void SaveUser(EmployeeMan EmpM)
	{
		Transaction tx = null;
    	try(Session session = sessionFactory.openSession())
    	{
    		 tx = session.beginTransaction();
		      session.save(EmpM);
		      tx.commit();
    	}
		
	}
	
	public EmployeeMan getempid(int id) 
	{
        Transaction transaction = null;
        EmployeeMan e2 = null;
        try (Session session = sessionFactory.openSession()) {
            // start the transaction
            transaction = session.beginTransaction();

            // get student object
            e2 = session.get(EmployeeMan.class, id);
            //student = session.load(Student.class, id);
            // commit the transaction
            transaction.commit();
        } 
        catch (Exception e)
        {
            if (transaction != null)
            {
                transaction.rollback();
            }
        }
        return e2;
    }
	
		
    public void deleteUser(int id)
    {
    	Transaction tx = null;
    	EmployeeMan EmpM = null;
    	try(Session session = sessionFactory.openSession())
    	{
    		 tx = session.beginTransaction();
    		 EmpM = session.get(EmployeeMan.class, id);
		      session.delete(EmpM);
		      tx.commit();
    	}
}
}