package com.example.dao;

import come.example.model.EmployeeMan;

public interface IEmployeeDao 
{
	void SaveUser(EmployeeMan EmpM);
	void deleteUser(int id);
	EmployeeMan getempid(int id);
}
