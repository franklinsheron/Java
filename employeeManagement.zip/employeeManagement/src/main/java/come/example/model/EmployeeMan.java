package come.example.model;
import lombok.*;
import javax.persistence.*;

@Entity
@Table(name = "emp")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString

public class EmployeeMan
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "Name")
	private String name;
	
	@Column(name = "Salary")
	private double salary;

	
}
