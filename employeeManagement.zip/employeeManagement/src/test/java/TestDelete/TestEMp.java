package TestDelete;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.example.dao.EmployeeDao;

import come.example.model.EmployeeMan;

public class TestEMp {

	@Test
	public void testEmployee() 
	{
		EmployeeDao  empdao = new EmployeeDao();
		EmployeeMan Emp = new EmployeeMan();
		EmployeeMan EmpM2 = new EmployeeMan();
		Emp.setName("Frank");
		Emp.setSalary(20000);
		EmpM2.setName("Alex");
		EmpM2.setSalary(10000);
		empdao.SaveUser(Emp);
		empdao.SaveUser(EmpM2);
		empdao.deleteUser(2);
		Assert.assertNull(null, empdao.getempid(2));
	}

}
